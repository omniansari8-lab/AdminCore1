package com.ags.admincore;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public final class AdminCore extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Set<UUID> vanished = new HashSet<>();
    private final Set<UUID> frozen = new HashSet<>();
    private final Set<UUID> god = new HashSet<>();
    private boolean lockdown = false;
    private BukkitTask animationTask;
    private int animationFrame = 0;
    private NamespacedKey actionKey;

    private static final String HOLDER_ID = "admincore-main";
    private static final int[] FRAME_SLOTS = {0, 1, 2, 3, 5, 6, 7, 8, 9, 17, 18, 19, 20, 21, 23, 24, 25, 26};

    @Override
    public void onEnable() {
        saveDefaultConfig();
        actionKey = new NamespacedKey(this, "action");
        for (String command : List.of("admincore", "ahelp", "help")) {
            PluginCommand c = getCommand(command);
            if (c != null) {
                c.setExecutor(this);
                c.setTabCompleter(this);
            }
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        startAnimation();
        getLogger().info("AdminCore 3.0.0 enabled.");
    }

    @Override
    public void onDisable() {
        if (animationTask != null) animationTask.cancel();
        for (UUID id : vanished) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) showToAll(p);
        }
        vanished.clear();
        frozen.clear();
        god.clear();
    }

    private void startAnimation() {
        if (!getConfig().getBoolean("gui.animation-enabled", true)) return;
        long interval = Math.max(1, getConfig().getLong("gui.animation-interval-ticks", 3));
        animationTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            animationFrame++;
            for (Player p : Bukkit.getOnlinePlayers()) {
                Inventory top = p.getOpenInventory().getTopInventory();
                if (top.getHolder() instanceof AdminHolder) paintFrame(top);
            }
        }, interval, interval);
    }

    private void paintFrame(Inventory inv) {
        Material[] frames = {Material.BLACK_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE,
                Material.PURPLE_STAINED_GLASS_PANE, Material.CYAN_STAINED_GLASS_PANE};
        for (int i = 0; i < FRAME_SLOTS.length; i++) {
            int slot = FRAME_SLOTS[i];
            ItemStack current = inv.getItem(slot);
            if (current != null && current.getType() != Material.AIR && !isFrame(current)) continue;
            Material material = frames[Math.floorMod(i + animationFrame, frames.length)];
            inv.setItem(slot, item(material, " ", null));
        }
    }

    private boolean isFrame(ItemStack item) {
        return item.getType().name().endsWith("_STAINED_GLASS_PANE")
                && item.getItemMeta() != null
                && " ".equals(item.getItemMeta().getDisplayName());
    }

    private void openGui(Player p) {
        if (!p.hasPermission("admincore.use")) {
            p.sendMessage(color("&cYou don't have permission to use AdminCore."));
            return;
        }
        String title = color(getConfig().getString("gui.title", "&8✦ &bAdminCore &8| &fControl Center"));
        Inventory inv = Bukkit.createInventory(new AdminHolder(), 27, title);
        inv.setItem(4, item(Material.NETHER_STAR, "&b&lADMINCORE", List.of("&7Control center", "&8Version 3.0.0")));
        inv.setItem(10, action(Material.ENDER_EYE, "&bVanish", "vanish", "&7Toggle your visibility."));
        inv.setItem(11, action(Material.FEATHER, "&bFlight", "fly", "&7Toggle flight mode."));
        inv.setItem(12, action(Material.GOLDEN_APPLE, "&bGod Mode", "god", "&7Toggle damage protection."));
        inv.setItem(13, action(Material.ICE, "&bFreeze Nearest", "freeze", "&7Freeze/unfreeze nearest player."));
        inv.setItem(14, action(Material.COMPASS, "&bTeleport", "teleport", "&7Teleport to nearest player."));
        inv.setItem(15, action(Material.CHEST, "&bPlayer Inventory", "inventory", "&7Open nearest player's inventory."));
        inv.setItem(16, action(Material.CLOCK, "&bSet Day", "day", "&7Set the world time to day."));
        inv.setItem(22, action(Material.BARRIER, lockdown ? "&cDisable Lockdown" : "&cEnable Lockdown", "lockdown", "&7Toggle join lockdown."));
        inv.setItem(4, item(Material.NETHER_STAR, "&b&lADMINCORE", List.of("&7Control center", "&8Space animation enabled")));
        paintFrame(inv);
        p.openInventory(inv);
    }

    private ItemStack action(Material type, String name, String action, String lore) {
        ItemStack stack = item(type, name, List.of(lore, "&8Click to execute"));
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, action);
        stack.setItemMeta(meta);
        return stack;
    }

    private ItemStack item(Material type, String name, List<String> lore) {
        ItemStack stack = new ItemStack(type);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(color(name));
        if (lore != null) meta.setLore(lore.stream().map(AdminCore::color).toList());
        stack.setItemMeta(meta);
        return stack;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof AdminHolder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getRawSlot() < 0 || e.getRawSlot() >= e.getView().getTopInventory().getSize()) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String action = clicked.getItemMeta().getPersistentDataContainer().get(actionKey, PersistentDataType.STRING);
        if (action == null) return;
        runAction(p, action);
        if (p.isOnline()) openGui(p);
    }

    private void runAction(Player p, String action) {
        switch (action) {
            case "vanish" -> toggleVanish(p);
            case "fly" -> {
                if (!allowed(p, "admincore.fly")) return;
                p.setAllowFlight(!p.getAllowFlight());
                p.sendMessage(color("&bFlight: " + (p.getAllowFlight() ? "&aON" : "&cOFF")));
            }
            case "god" -> {
                if (!allowed(p, "admincore.god")) return;
                toggle(god, p);
                p.sendMessage(color("&bGod mode: " + (god.contains(p.getUniqueId()) ? "&aON" : "&cOFF")));
            }
            case "freeze" -> {
                if (!allowed(p, "admincore.freeze")) return;
                Player target = nearest(p);
                if (target == null) { p.sendMessage(color("&cNo other online player found.")); return; }
                toggle(frozen, target);
                p.sendMessage(color("&b" + target.getName() + (frozen.contains(target.getUniqueId()) ? " &7frozen." : " &7unfrozen.")));
                target.sendMessage(color(frozen.contains(target.getUniqueId()) ? getConfig().getString("settings.freeze-message") : "&aYou are unfrozen."));
            }
            case "teleport" -> {
                if (!allowed(p, "admincore.teleport")) return;
                Player target = nearest(p);
                if (target == null) { p.sendMessage(color("&cNo other online player found.")); return; }
                p.teleport(target.getLocation());
                p.sendMessage(color("&aTeleported to " + target.getName() + "."));
            }
            case "inventory" -> {
                if (!allowed(p, "admincore.inventory")) return;
                Player target = nearest(p);
                if (target == null) { p.sendMessage(color("&cNo other online player found.")); return; }
                p.openInventory(target.getInventory());
            }
            case "day" -> {
                if (!allowed(p, "admincore.time")) return;
                p.getWorld().setTime(1000);
                p.sendMessage(color("&aTime set to day."));
            }
            case "lockdown" -> {
                if (!allowed(p, "admincore.lockdown")) return;
                lockdown = !lockdown;
                p.sendMessage(color("&cLockdown " + (lockdown ? "enabled." : "disabled.")));
            }
        }
    }

    private void toggleVanish(Player p) {
        if (!allowed(p, "admincore.vanish")) return;
        UUID id = p.getUniqueId();
        if (vanished.add(id)) {
            for (Player other : Bukkit.getOnlinePlayers()) if (!other.hasPermission("admincore.bypass")) other.hidePlayer(this, p);
            p.sendMessage(color("&bVanish: &aON"));
        } else {
            vanished.remove(id);
            showToAll(p);
            p.sendMessage(color("&bVanish: &cOFF"));
        }
    }

    private void showToAll(Player p) {
        for (Player other : Bukkit.getOnlinePlayers()) other.showPlayer(this, p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player joining = e.getPlayer();
        if (lockdown && !joining.hasPermission("admincore.bypass")) {
            Bukkit.getScheduler().runTask(this, () -> joining.kickPlayer(color(getConfig().getString("settings.lockdown-message"))));
            return;
        }
        for (UUID id : vanished) {
            Player hidden = Bukkit.getPlayer(id);
            if (hidden != null && !joining.hasPermission("admincore.bypass")) joining.hidePlayer(this, hidden);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!frozen.contains(e.getPlayer().getUniqueId()) || e.getTo() == null) return;
        if (e.getFrom().getBlockX() != e.getTo().getBlockX()
                || e.getFrom().getBlockY() != e.getTo().getBlockY()
                || e.getFrom().getBlockZ() != e.getTo().getBlockZ()) {
            e.setTo(e.getFrom());
        }
    }

    @EventHandler
    public void onDamage(org.bukkit.event.entity.EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && god.contains(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        frozen.remove(e.getPlayer().getUniqueId());
        god.remove(e.getPlayer().getUniqueId());
        vanished.remove(e.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("admincore")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("This command is for players."); return true; }
            openGui(p);
            return true;
        }
        if (name.equals("help") || name.equals("ahelp")) {
            sendHelp(sender, args);
            return true;
        }
        return true;
    }

    private void sendHelp(CommandSender sender, String[] args) {
        if (!sender.hasPermission("admincore.help")) { sender.sendMessage(color("&cNo permission.")); return; }
        if (args.length > 0 && args[0].equalsIgnoreCase("vanish")) {
            sender.sendMessage(color("&b/admincore &7- Open the AdminCore control center."));
            sender.sendMessage(color("&bVanish &7- Toggle visibility from the GUI."));
            return;
        }
        int page = 1;
        if (args.length > 0) {
            try { page = Integer.parseInt(args[0]); } catch (NumberFormatException ignored) { }
        }
        sender.sendMessage(color("&8&m---------------- &b&lAdminCore Help &8&m----------------"));
        sender.sendMessage(color("&bPage " + Math.max(1, Math.min(page, 2)) + "&7/2"));
        if (page <= 1) {
            sender.sendMessage(color("&b/admincore &7- Open the single animated admin GUI."));
            sender.sendMessage(color("&b/ahelp [page|command] &7- AdminCore help."));
            sender.sendMessage(color("&b/help [page|command] &7- AdminCore help."));
            sender.sendMessage(color("&7GUI tools: vanish, flight, god mode, freeze, teleport, inventory, day, lockdown."));
        } else {
            sender.sendMessage(color("&7Permissions:"));
            for (String perm : List.of("vanish", "fly", "god", "freeze", "teleport", "inventory", "time", "lockdown"))
                sender.sendMessage(color("&badmincore." + perm + " &7- Access to that control."));
            sender.sendMessage(color("&7admincore.bypass &7- Bypass vanish and lockdown."));
        }
        sender.sendMessage(color("&8&m------------------------------------------------"));
    }

    private boolean allowed(Player p, String permission) {
        if (p.hasPermission(permission)) return true;
        p.sendMessage(color("&cMissing permission: " + permission));
        return false;
    }

    private Player nearest(Player p) {
        return Bukkit.getOnlinePlayers().stream().filter(x -> !x.equals(p))
                .min(Comparator.comparingDouble(x -> x.getLocation().distanceSquared(p.getLocation())))
                .orElse(null);
    }

    private void toggle(Set<UUID> set, Player p) {
        if (!set.add(p.getUniqueId())) set.remove(p.getUniqueId());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("help") || command.getName().equalsIgnoreCase("ahelp"))
            return args.length == 1 ? List.of("1", "2", "vanish") : List.of();
        return List.of();
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    private static final class AdminHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
}
